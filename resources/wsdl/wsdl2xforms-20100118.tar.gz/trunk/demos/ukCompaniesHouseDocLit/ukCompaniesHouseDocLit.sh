#!/bin/sh
cd ../../bin
./wsdl2xforms.sh ../demos/ukCompaniesHouseDocLit/ukCompaniesHouseEmulatorDocLit.wsdl ../demos/ukCompaniesHouseDocLit/out
cd ../demos/ukCompaniesHouseDocLit
