#!/bin/sh
cd ../../bin
./wsdl2xforms.sh ../demos/GoogleSearch/GoogleSearch.wsdl ../demos/GoogleSearch/g
cd ../demos/GoogleSearch
